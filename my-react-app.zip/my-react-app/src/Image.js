import React from 'react'
import './Image.css'
const Image = () => {
  return (
    <div className='outPut'>
        <img src={
           "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSCZlf5lc5tX-0gY-y94pGS0mQdL-D0lCH2OQ&usqp=CAU"}>
        </img>
    </div>
  )
}

export default Image